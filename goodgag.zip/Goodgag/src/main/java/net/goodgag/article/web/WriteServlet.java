package net.goodgag.article.web;

import java.io.IOException;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.goodgag.article.dao.ArticleDao;
import net.goodgag.article.vo.ArticleVO;

@WebServlet("/write")
public class WriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ArticleDao articleDao;
	
	public WriteServlet() {
		articleDao = ArticleDao.getInstance();
	}
//보여주기
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/article/write.jsp");
		rd.forward(request, response);
	}
//처리하기
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String title = request.getParameter("title");
		String writer = request.getParameter("writer");
		String body = request.getParameter("body");

		ArticleVO article = new ArticleVO();
		article.setTitle(title);
		article.setWriter(writer);
		article.setBody(body);
		article.setWriteDateTime(getDateTime());
		
		articleDao.save(article);
		response.sendRedirect("/Goodgag/list");
	}

	// 시스템 날짜 가져오기
	private String getDateTime() {
		// 현재 시간을 가진 객체가 만들어짐
		Calendar cal = Calendar.getInstance();
		// 년 월 일 시 분
		int year = cal.get(Calendar.YEAR);
		// 1월이 0 , 12월이 11 --> 숫자 늘려줘야 됨
		int month = cal.get(Calendar.MONTH) + 1;
		int date = cal.get(Calendar.DAY_OF_MONTH);
		int hour = cal.get(Calendar.HOUR_OF_DAY);
		int minute = cal.get(Calendar.MINUTE);

		// 2018-02-21 10:55
		/*
		 * String dateTime = year + "-" + fillZero(month) + "-" + fillZero(date) + " " +
		 * fillZero(hour) + ":" + fillZero(minute);
		 */

		// 숫자 : %d, 문자 : %s 실수 : %f 소수점이하 두자리의 실수 : %.2f
		String dateTime = String.format("%d-%s-%s %s:%s", 
				year, fillZero(month), fillZero(date), fillZero(hour), fillZero(minute));

		return dateTime;
	}

	// 10보다 작은 수는 앞에 0을 붙여서 01 02 이렇게 만들어주기
	private String fillZero(int number) {
		if (number < 10) {
			return "0" + number;
		} else {
			return number + "";// 문자니까 공백주기
		}
	}

}
