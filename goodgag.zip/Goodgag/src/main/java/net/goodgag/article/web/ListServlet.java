package net.goodgag.article.web;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.goodgag.article.dao.ArticleDao;
import net.goodgag.article.vo.ArticleVO;

@WebServlet("/list")
public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ArticleDao articleDao;
	
	//초기화는 생성자에서!!
	public ListServlet() {
		//articleDao = new ArticleDao();
		articleDao = ArticleDao.getInstance();
	}
	//하나의 서블릿에 보여주기만 있으면 doget에서 dopost로 이동해서 post에서 보여주는 거 처리하기
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("URL로 접근함!");
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		//리스트를 만들어서 새로운 어레이리스트에 할당시킬거다
		//리스트의 메모리를 새로 부여한 거임
		//dao에 있는 메모리랑 다름!!
		List<ArticleVO> articleList = new ArrayList<ArticleVO>();	
		//위에 리스트의 메모리를 사용하지 않고 다른거로 재할당 시킴
		//--> 메모리 오버플로우 발생
		articleList = articleDao.getAll();		
		*/		
		
		//dao에 있는 메모리를 받아와서 articleList로 사용하도록 할 수 있음
		List<ArticleVO> articleList =  articleDao.getAll();
				
		request.setAttribute("articleList", articleList);
		RequestDispatcher rd = request.getRequestDispatcher
				("/WEB-INF/view/article/list.jsp");
		//위에 페이지를 읽어서 사용자에게 보여줘라
		rd.forward(request, response);
		
		
		
	}

}
