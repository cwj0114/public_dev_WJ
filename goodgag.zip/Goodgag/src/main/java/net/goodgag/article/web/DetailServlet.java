package net.goodgag.article.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.goodgag.article.dao.ArticleDao;
import net.goodgag.article.vo.ArticleVO;


@WebServlet("/detail")
public class DetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ArticleDao articleDao;
	
    public DetailServlet() {
       articleDao = ArticleDao.getInstance(); 
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String idStr = request.getParameter("id");
		if ( idStr == null) {
			idStr ="";
		}
		int id =0;
		try {
			id = Integer.parseInt(idStr);
		}catch (NumberFormatException nfe){
			id = 0;
		}
				
		ArticleVO articleDetail =  articleDao.get(id);
		request.setAttribute("articleDetail", articleDetail);
		
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/article/detail.jsp");
		rd.forward(request, response);
	}

}
