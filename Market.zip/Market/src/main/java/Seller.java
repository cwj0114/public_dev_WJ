
public class Seller {
	
	public final int PRICE = 10_000;
		
	private int stock;
	private long money;
	
	public Seller(int stock, long money) {
		this.stock = stock;
		this.money = money;
	}
	
	public long getMoney() {
		return money;
	}
	
	public int getStock() {
		return stock;
	}
	
	public void sell(Buyer buyer, int unit) {
		stock -= unit;
		money += PRICE * unit;
		buyer.buy(this, unit);
	}
	
}
