
public class Department {
	
	private final int RENTAL_FEE = 50_000;
	
	/*
	 * 매장
	 */
	private Seller[] storeArray;
	
	void rental() {
		// TODO 판매자에게 백화점의 매장 자리를 임대함.
	}
	
	void release() {
		// TODO 지정된 판매자의 임대를 해지함.
	}
	
}
