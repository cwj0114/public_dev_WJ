import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class IndexServlet extends HttpServlet{
	
	private Seller[] sellerArray;
	private Buyer[] buyerArray;
		
	public IndexServlet() {
	
		sellerArray = new Seller[3];
		sellerArray[0] = new Seller(50, 500_000);
		sellerArray[1] = new Seller(60, 300_000);
		sellerArray[2] = new Seller(30, 1_000_000);
		
		buyerArray = new Buyer[2];
		buyerArray[0] = new Buyer(300_000);
		buyerArray[1] = new Buyer(100_000);
		
//		shoeSeller = new Seller(50, 500_000);
//		capSeller = new Seller(60, 300_000);
//		bagSeller = new Seller(30, 1_000_000);
//		
//		lyg = new Buyer(300_000);
//		hhj = new Buyer(100_000);
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		// 파라미터 받아오기
		String buyerStr = req.getParameter("buyer");
		
		if ( buyerStr == null) {
			buyerStr = "";
		}
		
		int buyer = 0;
		try {
			buyer = Integer.parseInt(buyerStr);
		}
		catch ( NumberFormatException nfe ) {
			buyer = 0;
		}
		
		String sellerStr = req.getParameter("seller");
		
		if ( sellerStr == null) {
			sellerStr = "";
		}
		
		int seller = 0;
		try {
			seller = Integer.parseInt(sellerStr);
		}
		catch ( NumberFormatException nfe ) {
			seller = 0;
		}	
		String unitStr = req.getParameter("unit");
		if ( unitStr == null) {
			unitStr = "0";
		}
		
		int unit = 0;
		try {
			unit = Integer.parseInt(unitStr);
		}
		catch ( NumberFormatException nfe ) {
			unit = 0;
		}
		
		sellerArray[seller].sell(buyerArray[buyer], unit);
		
		req.setAttribute("sellerArray", sellerArray);
		req.setAttribute("buyerArray", buyerArray);
		
//		if ( seller.equals("shoe") ) {
//			
//			if ( buyer.equals("lyg") ) {
//				shoeSeller.sell(lyg, unit);
//			}
//			else if ( buyer.equals("hhj") ) {
//				shoeSeller.sell(hhj, unit);
//			}
//			
//		}		
//		else if ( seller.equals("bag") ) {
//			
//			if ( buyer.equals("lyg") ) {
//				bagSeller.sell(lyg, unit);
//			}
//			else if ( buyer.equals("hhj") ) {
//				bagSeller.sell(hhj, unit);
//			}
//			
//		}
//		else if ( seller.equals("cap") ) {
//			
//			if ( buyer.equals("lyg") ) {
//				capSeller.sell(lyg, unit);
//			}
//			else if ( buyer.equals("hhj") ) {
//				capSeller.sell(hhj, unit);
//			}
//			
//		}
		
//		req.setAttribute("shoe", shoeSeller);
//		req.setAttribute("cap", capSeller);
//		req.setAttribute("bag_money", bagSeller.getMoney());
//		req.setAttribute("bag_stock", bagSeller.getStock());
//		
//		req.setAttribute("lyg_money", lyg.getMoney());
//		req.setAttribute("lyg_stock", lyg.getStock());
//		req.setAttribute("hhj", hhj);
				
		// IndexServlet을 요청하면, index.jsp를 브라우저에게 전달함.
		RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/view/index.jsp");
		rd.forward(req, resp);
	}
	
}
	

