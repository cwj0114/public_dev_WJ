import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class IndexServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		Seller shoeSeller = new Seller(50, 500_000);
		Seller capSeller = new Seller(60, 300_000);
		Seller bagSeller = new Seller(30, 1_000_000);
		
		Buyer lyg = new Buyer(300_000);
		Buyer hhj = new Buyer(100_000);
		
		bagSeller.sell(lyg, 10);
		capSeller.sell(lyg, 5);
		shoeSeller.sell(hhj, 2);
		
		System.out.println(lyg.getMoney());
		
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
}
