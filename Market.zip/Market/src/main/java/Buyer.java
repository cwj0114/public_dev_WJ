
public class Buyer {

	private long money;
	
	/*
	 * 장바구니
	 */
	private int stock;
	
	public Buyer(long money) {
		this.money = money;
	}
	
	public long getMoney() {
		return money;
	}
	
	public int getStock() {
		return stock;
	}
	
	public void buy(Seller seller, int unit) {
		money -= seller.PRICE * unit;
		stock += unit;
	}
			
}
