
public class Buyer {

	private int stock;
	private long money;	
	
	public Buyer(long money) {
		this.money = money;
	}
	
	public long getMoney() {
		return money;
	}
	
	public int getStock() {
		return stock;
	}
	
	public void buy(Seller seller, int unit) {
		money -= seller.PRICE * unit;
		stock += unit;
	}
			
}
