package com.ktds.community.web;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ktds.community.service.CommunityService;
import com.ktds.community.vo.CommunityVO;
import com.ktds.member.constants.Member;

@Controller
public class CommunityController {
	
	private CommunityService communityService;
	
	public void setCommunityService(CommunityService communityService) {
		this.communityService = communityService;
	}
	
	@RequestMapping("/")
	public ModelAndView list(HttpSession session) {
		
		if ( session.getAttribute(Member.USER )== null ) {
			return new ModelAndView("redirect:/login");
		}
		
		ModelAndView view = new ModelAndView();
		view.setViewName("community/list");
		
		
		List<CommunityVO> communityList = communityService.getAll(); 
		view.addObject("communityList", communityList);
		
		return view;
	}
	
	//@GetMapping("/write")
	@RequestMapping(value = "/write", method= RequestMethod.GET)
	public String write(HttpSession session) {
		if ( session.getAttribute(Member.USER )== null ) {
			return "redirect:/login";
		}
		return "community/write";
	}
	
	//spring 4.3부터 가능
	//@PostMapping("/write")
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public ModelAndView doWrite(@ModelAttribute("writeForm") 
								 @Valid CommunityVO communityVO, Errors errors, HttpSession session) {
				
//		if ( communityVO.getTitle() == null || communityVO.getTitle().length() == 0 ) {
//			session.setAttribute("status", "emptyTitle");
//			return new ModelAndView("redirect:/write");
//		}
//		
//		if ( communityVO.getBody() == null || communityVO.getBody().length() == 0 ) {
//			session.setAttribute("status", "emptyBody");
//			return new ModelAndView("redirect:/write");
//		}
//		
//		if (communityVO.getWriteDate() == null || communityVO.getWriteDate().length() == 0 ) {
//			session.setAttribute("status", "emptyWriteDate");
//			return new ModelAndView("redirect:/write");
//		}
		
		// 글쓰기를 하는데 30 분넘게 하면 session 팅김 -> 재로그인
		if ( session.getAttribute(Member.USER ) == null ) {
			return new ModelAndView("redirect:/login");
		}
		
		// 필수입력값 넣어라
		if ( errors.hasErrors() ) {
			ModelAndView view = new ModelAndView();
			view.setViewName("community/write");
			view.addObject("communityVO", communityVO);
			return view;
		}
		
		boolean isSuccess = communityService.createCommunity(communityVO);
		
		if ( isSuccess )  {
			return new ModelAndView("redirect:/");
	
		}
		else {
			return new ModelAndView("redirect:/write");
		}
	}
	
	@RequestMapping("/detail/{id}")
	   public ModelAndView viewDetailList(HttpSession session, @PathVariable int id) {
		
		if ( session.getAttribute(Member.USER) == null ) {
			return new ModelAndView("redirect:/login");
		}
	      ModelAndView view = new ModelAndView();
	      view.setViewName("community/detail");

	      CommunityVO detail = communityService.getOne(id);
	      boolean isLast = communityService.isLastId(id);
	      view.addObject("isLast", isLast);
	      if ( detail != null ) {
	         view.addObject("detail", detail);
	      }
	      return view;
	   }
	
	@RequestMapping("/read/{id}")
	public String readPage(HttpSession session, @PathVariable int id) {
		if ( session.getAttribute(Member.USER) == null ) {
			return "redirect:/login";
		}
		
		if ( communityService.increaseViewCount(id) ) {
			return "redirect:/detail/"+id;
		}
		return "redirect:/";
		
	}
	
	@RequestMapping("/remove/{id}")
	   public String viewRemovelList(HttpSession session, @PathVariable int id) {
		
		if ( session.getAttribute(Member.USER) == null ) {
			return "redirect:/login";
		}
		
	      boolean remove = communityService.removeCommunity(id);

	         if ( remove ) {
	            return "redirect:/";
	         }
	      return "redirect:/detail";
	   }
	
	@RequestMapping("/recommend/{id}")
	public String doRecommend(HttpSession session, @PathVariable int id) {
		if ( session.getAttribute(Member.USER) == null ) {
			return "redirect:/login";
		}
		
		if ( communityService.increaseRecommendCount(id) ) {
			return "redirect:/detail/"+id;
		}
		return "redirect:/detail/"+id;
	}

}
