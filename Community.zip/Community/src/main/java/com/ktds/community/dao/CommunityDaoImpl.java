package com.ktds.community.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.jasper.tagplugins.jstl.core.ForEach;

import com.ktds.community.vo.CommunityVO;

public class CommunityDaoImpl implements CommunityDao {

	private List<CommunityVO> communityList;

	public CommunityDaoImpl() {
		communityList = new ArrayList<CommunityVO>();
	}

	@Override
	public List<CommunityVO> selectAll() {
		return communityList;
	}

	@Override
	public int insertCommunity(CommunityVO communityVO) {
		communityVO.setId(communityList.size() + 1);
		communityList.add(communityVO);
		return 1;
	}

	@Override
	public int deleteCommunity(int id) {
		for (CommunityVO communityVO : communityList) {
			if (communityVO.getId() == id) {
				int titleIndex = communityList.indexOf(communityVO);
				communityList.remove(titleIndex);
				for (CommunityVO communityVO1 : communityList) {
					int newId = communityList.indexOf(communityVO1);
					communityVO1.setId(newId + 1);
				}
				return 1;
			}
		}
		return 0;
	}

	@Override
	public CommunityVO selectOne(int id) {
		for (CommunityVO communityVO : communityList) {
			if (communityVO.getId() == id) {
				return communityVO;
			}
		}
		return null;
	}

	@Override
	public int updateViewCount(int id) {
		for (CommunityVO communityVO : communityList) {
			if (communityVO.getId() == id) {
				communityVO.setViewCount(communityVO.getViewCount() +1);
				return 1;
			}
		}
		return 0;
	}
	
	@Override
	public boolean isLast(int id) {
		int lastIndex = communityList.size();
		if (id == lastIndex) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int updateRecoomendCount(int id) {
		for (CommunityVO communityVO : communityList) {
			if(communityVO.getId() == id) {
				communityVO.setRecommendCount(communityVO.getRecommendCount()+1);
				return 1;
			}
		}
		return 0;
	}

	

}
