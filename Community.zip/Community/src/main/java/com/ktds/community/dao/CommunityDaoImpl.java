package com.ktds.community.dao;

import java.util.ArrayList;
import java.util.List;

import com.ktds.community.vo.CommunityVO;

public class CommunityDaoImpl implements CommunityDao {

	private List<CommunityVO> communityList;

	public CommunityDaoImpl() {
		communityList = new ArrayList<CommunityVO>();
	}
	
	@Override
	public List<CommunityVO> selectAll() {
		return communityList;
	}
	
	public int insertCommunity(CommunityVO communityVO) {
		communityVO.setId( communityList.size() + 1 );
		communityList.add(communityVO);
		return 1;
	}
	
	

}
