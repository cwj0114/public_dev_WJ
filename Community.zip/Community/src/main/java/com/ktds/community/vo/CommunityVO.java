package com.ktds.community.vo;

import javax.validation.constraints.NotEmpty;

public class CommunityVO {

	private int id;
	
	@NotEmpty(message="제목은 필수 입력입니다.")
	private String title;
	@NotEmpty(message="내용은 필수 입력입니다.")
	private String body;
	@NotEmpty(message="로그인이 필요합니다.")
	private String nickname;
	@NotEmpty(message="로그인이 필요합니다.")
	private String userId;
	@NotEmpty(message="작성일을 선택해 주세요.")
	private String writeDate;
	
	private int viewCount;
	private int recommendCount;

	public int getRecommendCount() {
		return recommendCount;
	}

	public void setRecommendCount(int recommendCount) {
		this.recommendCount = recommendCount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickName) {
		this.nickname = nickName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getWriteDate() {
		return writeDate;
	}

	public void setWriteDate(String writeDate) {
		this.writeDate = writeDate;
	}

	public int getViewCount() {
		return viewCount;
	}

	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}

}
