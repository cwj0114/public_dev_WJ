package com.ktds.community.vo;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ktds.community.service.CommunityService;

@Controller
public class CommunityController {
	
	private CommunityService communityService;
	
	public void setCommunityService(CommunityService communityService) {
		this.communityService = communityService;
	}

	@RequestMapping("/")
	public ModelAndView viewListPage() {
		ModelAndView view = new ModelAndView();
		
		// /WEB-INF/view/community/list.jsp
		view.setViewName("community/list");
		
		List<CommunityVO> communityList = communityService.getall();
		view.addObject("communityList", communityList);
		
		return view;
	}
	
	// @RequestMapping(value = "/write", method = RequestMethod.GET)
	@GetMapping("/write")
	public String viewWritePage() {
		return "community/write";
	}
	
	// @RequestMapping(value = "/write", method = RequestMethod.POST)
	@PostMapping("/write")
	public String doWrite(CommunityVO communityVO) {
		
		boolean isSuccess = communityService.createCommunity(communityVO);
		
		if ( isSuccess ) {
			return "redirect:/";
		}
		
		return "redirect:/write";
	}
	
}
