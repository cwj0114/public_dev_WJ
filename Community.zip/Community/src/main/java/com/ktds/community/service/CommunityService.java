package com.ktds.community.service;

import java.util.List;

import com.ktds.community.vo.CommunityVO;

public interface CommunityService {

	public List<CommunityVO> getall();

	public boolean createCommunity(CommunityVO communityVO);
	
}
