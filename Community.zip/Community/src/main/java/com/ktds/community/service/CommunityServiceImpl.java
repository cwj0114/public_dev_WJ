package com.ktds.community.service;

import java.util.List;

import com.ktds.community.dao.CommunityDao;
import com.ktds.community.vo.CommunityVO;

public class CommunityServiceImpl implements CommunityService{
	
	private CommunityDao communityDao;

	public void setCommunityDao(CommunityDao communityDao) {
		this.communityDao = communityDao;
	}

	@Override
	public List<CommunityVO> getall() {
		return communityDao.selectAll();
	}
	
	@Override
	public boolean createCommunity(CommunityVO communityVO) {
		int insertCount = communityDao.insertCommunity(communityVO);
		return insertCount > 0;
	}
	
}
