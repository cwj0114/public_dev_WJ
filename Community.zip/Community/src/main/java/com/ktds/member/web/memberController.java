package com.ktds.member.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ktds.member.constants.Member;
import com.ktds.member.vo.MemberVO;

@Controller
public class memberController {
	
	@RequestMapping(value = "/login", method=RequestMethod.GET)
	public String viewLoginPage(HttpSession session) {
		
		if(session.getAttribute(Member.USER) != null) {
			return "redirect:/";
		}
		
		return "member/login";
	}
	
	@RequestMapping(value = "/login", method=RequestMethod.POST)
	public String doLoginAction(MemberVO memberVO, HttpServletRequest request) {

		HttpSession session = request.getSession();
		
		if( memberVO.getId() == null || memberVO.getId().length() == 0 ) {
			session.setAttribute("status", "emptyId");
			return "redirect:/login";
		}
		if( memberVO.getPassword() == null || memberVO.getPassword().length() == 0) {
			session.setAttribute("status", "emptyPW");
			return "redirect:/login";
		}
		
		
		if(memberVO.getId().equals("admin") && memberVO.getPassword().equals("1234")) {
			
			memberVO.setNickname("관리자");
			
			session.setAttribute(Member.USER, memberVO);
			
			return "redirect:/";
		}
		
		session.setAttribute("status", "fail");
		
		return "redirect:/login";
	}

	@RequestMapping("/logout")
	public String doLogOut(HttpSession session) {
		
		session.invalidate();
		
		return "redirect:/";
	}
	
}
