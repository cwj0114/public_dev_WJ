import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MultiplicationServlet extends HttpServlet{
	
	private int one;
	private int two;
	private int result;
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String oneStr = req.getParameter("one");		
		
		if ( oneStr == null) {
			oneStr = "0";
		}				
		try {
			one = Integer.parseInt(oneStr);
		}
		catch ( NumberFormatException nfe ) {
			one = 0;
		}
		
		String twoStr = req.getParameter("two");		
		if ( twoStr == null) {
			twoStr = "0";
		}		
		try {
			two = Integer.parseInt(twoStr);
		}
		catch ( NumberFormatException nfe ) {
			two = 0;
		}
				
		req.setAttribute("one", one);
		req.setAttribute("two", two);	
		req.setAttribute("result", one * two);	
		
		RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/view/index.jsp");
		rd.forward(req, resp);
	}
}

