package starcraft;

public interface TankUnit extends MechanicUnit {

	public void siegeMode();
	public void tankMode();
}
