package starcraft;

public interface VultureUnit extends MechanicUnit {

	public void mine();
}
