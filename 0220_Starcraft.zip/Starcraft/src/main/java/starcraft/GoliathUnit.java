package starcraft;

public interface GoliathUnit extends MechanicUnit {

}
