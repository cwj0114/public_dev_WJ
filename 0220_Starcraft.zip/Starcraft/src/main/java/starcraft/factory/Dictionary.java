package starcraft.factory;

import java.util.HashMap;
import java.util.Map;

public class Dictionary {

	public static void main(String[] args) {
		
		Map<String, String> dict = new HashMap<String, String>();
		dict.put("English", "[명사] 영어");
		dict.put("Korean", "[명사] 한국어");
		
		String value = dict.get("English");
		System.out.println(value);
		
	}
	
}
