package starcraft.factory;

import starcraft.TankUnit;

public class SeigeTank implements TankUnit {

	int seigeState = 0;
	
	
	@Override
	public void move() {
		if(seigeState == 1) {
			System.out.println("시즈모드에선 움직일수 없어 친구.");
		}
		else {
			System.out.println("탱크 나가신다 길을비켜라!");
		}
	}

	@Override
	public void stop() {
		System.out.println("내 연료는 아직 남아있어!");
	}

	@Override
	public void attack() {
		if (seigeState == 1) {
			System.out.println("펑!!!!!");
		}
		else {
			System.out.println("퉁 쾅");
		}
	}

	@Override
	public void patroll() {
		if(seigeState == 1) {
			System.out.println("시즈모드에선 움직일수 없어 친구.");
		}
		else {
			System.out.println("옛! 썰!");
		}
	}

	@Override
	public void hold() {
		System.out.println("탱크 사수!");
	}

	@Override
	public void siegeMode() {
		seigeState = 1;
		System.out.println("치이이잉 키이이잉! *시즈모드완료");
	}

	@Override
	public void tankMode() {
		seigeState = 0;
		System.out.println("키이이잉 치이이잉. *탱크모드완료");
	}

}
