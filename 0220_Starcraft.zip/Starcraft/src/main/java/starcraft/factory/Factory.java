package starcraft.factory;

import java.util.ArrayList;
import java.util.List;

import starcraft.MechanicUnit;
import starcraft.TankUnit;

public class Factory {

	public MechanicUnit createNumber(int unitType) {
		
		if(unitType == 1) {
			return new Vulture();
		}
		else if (unitType == 2) {
			return new SeigeTank();
		}
		else if (unitType == 3) {
			return new Goliath();
		}
		else {
			return null;
		}
		
	}
	
	
	public static void main(String[] args) {
					
				
		List<MechanicUnit> unitList = new ArrayList<MechanicUnit>();		
		
		unitList.add(new Vulture());
		unitList.add(new Vulture());
		unitList.add(new Vulture());
		unitList.add(new Vulture());
		unitList.add(new Vulture());
		unitList.add(new SeigeTank());
		unitList.add(new SeigeTank());
		unitList.add(new SeigeTank());
		unitList.add(new SeigeTank());
		unitList.add(new SeigeTank());
		unitList.add(new Goliath());
		unitList.add(new Goliath());
		unitList.add(new Goliath());
		unitList.add(new Goliath());
		unitList.add(new Goliath());
		
		
		MechanicUnit unit = unitList.get(0);
		unit.attack();
		
		MechanicUnit tank = unitList.get(5);
		tank.attack();
		
		if( tank instanceof SeigeTank) {
			((SeigeTank) tank).siegeMode();
		}
		tank.attack();
		
		MechanicUnit mUnit2 = null;
		for ( int i = 0; i < unitList.size(); i++ ) {
			mUnit2 = unitList.get(i);
			mUnit2.attack();
		}
		
		for ( MechanicUnit mUnit : unitList ) {
			mUnit.attack();
		}
			
		
		
	}
}
