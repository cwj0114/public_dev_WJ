package starcraft.factory;

import starcraft.GoliathUnit;

public class Goliath implements GoliathUnit {

	@Override
	public void move() {
		System.out.println("골리앗 움직인다.");
	}

	@Override
	public void stop() {
		System.out.println("골리앗 멈췄다.");
	}

	@Override
	public void attack() {
		System.out.println("휘리리리링 휘리리리리링 *공중공격소리");
		System.out.println("타다다당 타다다당 *지상공격소리");
	}

	@Override
	public void patroll() {
		System.out.println("골리앗 정찰한다.");
	}

	@Override
	public void hold() {
		System.out.println("골리앗 사수한다.");
	}

}
