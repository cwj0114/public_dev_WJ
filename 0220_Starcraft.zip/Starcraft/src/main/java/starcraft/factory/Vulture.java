package starcraft.factory;

import starcraft.VultureUnit;;

public class Vulture implements VultureUnit  {

	@Override
	public void move() {
		System.out.println("벌쳐나가신다!");
	}

	@Override
	public void stop() {
		System.out.println("난 더 움직일 수 있다고.");
	}

	@Override
	public void attack() {
		System.out.println("푱~ 팡!");
	}

	@Override
	public void patroll() {
		System.out.println("충성");
	}

	@Override
	public void hold() {
		System.out.println("벌쳐 사수!");
	}

	@Override
	public void mine() {
		for( int i = 0; i < 3; i += 1) {
			System.out.println("마인을 " + i + "개 심었다.");
		}
	}



}
