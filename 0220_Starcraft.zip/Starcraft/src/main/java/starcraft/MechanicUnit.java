package starcraft;

public interface MechanicUnit {

	public void move();
	public void stop();
	public void attack();
	public void patroll();
	public void hold();
}
