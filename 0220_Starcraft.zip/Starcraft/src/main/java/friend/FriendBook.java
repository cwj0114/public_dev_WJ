package friend;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FriendBook {

	private List<Friend> friendList;
		
	public void start() {
		// List로 6명 이상의 친구 등록하고 출력하기
		// List<친구>
		friendList = new ArrayList<Friend>();
		friendList.add(new Friend("첫번째 친구","010 1234 5678"));
		friendList.add(new Friend("두번째 친구","010 1234 5678"));
		friendList.add(new Friend("세번째 친구","010 1234 5678"));
		friendList.add(new Friend("네번째 친구","010 1234 5678"));
		friendList.add(new Friend("다섯번째 친구","010 1234 5678"));
		friendList.add(new Friend("여섯번째 친구","010 1234 5678"));
		
		for ( Friend friend : friendList) {
			System.out.println(friend.getName() + friend.getName());
		}
		
		// Map으로 10명 이상의 친구 등록하고 출력하기
		// Map<이름, 친구>
		Map<String, Friend> friendMap = new HashMap<String, Friend>();
		friendMap.put("첫번째 친구",new Friend("첫번째 친구", "010 1234 5678"));
		friendMap.put("첫번째 친구",new Friend("두번째 친구", "010 1234 5678"));
		friendMap.put("첫번째 친구",new Friend("세번째 친구", "010 1234 5678"));
		friendMap.put("첫번째 친구",new Friend("네번째 친구", "010 1234 5678"));
		friendMap.put("첫번째 친구",new Friend("다섯번째 친구", "010 1234 5678"));
		friendMap.put("첫번째 친구",new Friend("여섯번째 친구", "010 1234 5678"));
				
//		System.out.println( friendMap.get("첫번째 친구").getName() + " / " 
//								+ friendMap.get("첫번째 친구").getPhone());

		Iterator<String> keys = friendMap.keySet().iterator();
		while ( keys.hasNext() ) {
			String key = keys.next();
			Friend friend = friendMap.get(key);
			System.out.println( friend.getName() + " / " + friend.getPhone());
		}

	}
	
	public void main(String[] args) {
		new FriendBook().start();
	}
	
}
