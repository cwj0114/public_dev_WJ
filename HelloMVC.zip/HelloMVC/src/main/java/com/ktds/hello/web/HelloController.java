package com.ktds.hello.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
	
	// http://localhost:8080/HelloMVC/hello
	// GET
	@RequestMapping("/hello")
	public String viewHelloPage() {
		
		
		// prefix + hello + suffix
		// /WEB-INF/view/hello.jsp
		
		// RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/hello.jsp");
		// rd.forward(request, response);
		return "hello";
	}
	
	@RequestMapping("/me")
	public String viewMePage() {
		return "me";
	}
}
