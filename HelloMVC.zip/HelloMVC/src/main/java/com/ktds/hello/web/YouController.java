package com.ktds.hello.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class YouController {

	@RequestMapping("/you")
	public ModelAndView viewYouPage() {
		
		ModelAndView view = new ModelAndView("you");
		//view.setViewName("you");
		
		view.addObject("name", "최원준");
		view.addObject("major", "정보통신공학");
		
		return view;
	}
	
}
