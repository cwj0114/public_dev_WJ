package net.youtube.video.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.youtube.video.dao.YoutubeDao;
import net.youtube.video.vo.YoutubeVO;

@WebServlet("/list")
public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private YoutubeDao youtubeDao;
    public ListServlet() {
    	youtubeDao = YoutubeDao.getInstance();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		List<YoutubeVO> youtubeList = youtubeDao.getAll();
		
		request.setAttribute("youtubeList", youtubeList);
		
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/video/list.jsp");
		rd.forward(request, response);
	}

	
}
