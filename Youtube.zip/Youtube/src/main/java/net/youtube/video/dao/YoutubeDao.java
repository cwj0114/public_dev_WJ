package net.youtube.video.dao;

import java.util.ArrayList;
import java.util.List;

import net.youtube.video.vo.YoutubeVO;

public class YoutubeDao {

	private static YoutubeDao youtubeDao;
	
	private List<YoutubeVO> youtubeList;
	private int id;
	
	private YoutubeDao() {
		youtubeList = new ArrayList<YoutubeVO>();
		
		YoutubeVO youtubeVO = new YoutubeVO();
		youtubeVO.setBody("내용");
		youtubeVO.setDate("2018-02-23");
		youtubeVO.setId(++id);
		youtubeVO.setImage("burnitup.PNG");
		youtubeVO.setTitle("[엘리가 간다]제주도 신화테마파크에서 스릴만점 회전 롤러코스터와 놀이기구 체험!");
		youtubeVO.setUploader("작성자");
		youtubeList.add(youtubeVO);
		

		youtubeVO = new YoutubeVO();
		youtubeVO.setBody("내용");
		youtubeVO.setDate("2018-02-23");
		youtubeVO.setId(++id);
		youtubeVO.setImage("jihun.PNG");
		youtubeVO.setTitle("[엘리가 간다]제주도 신화테마파크에서 스릴만점 회전 롤러코스터와 놀이기구 체험!");
		youtubeVO.setUploader("작성자");
		youtubeList.add(youtubeVO);
		
		youtubeVO = new YoutubeVO();
		youtubeVO.setBody("내용");
		youtubeVO.setDate("2018-02-23");
		youtubeVO.setId(++id);
		youtubeVO.setImage("minhyeon.PNG");
		youtubeVO.setTitle("[엘리가 간다]제주도 신화테마파크에서 스릴만점 회전 롤러코스터와 놀이기구 체험!");
		youtubeVO.setUploader("작성자");
		youtubeList.add(youtubeVO);

				
	}
	
	public static YoutubeDao getInstance() {
		if ( youtubeDao == null ) {
			youtubeDao = new YoutubeDao();
		}
		
		return youtubeDao;
	}
	
	public void save(YoutubeVO youtubeVO) {
		youtubeVO.setId(++id);
		youtubeList.add(youtubeVO);
	}
	
	public List<YoutubeVO> getAll() {
		return youtubeList;
	}
	
	public YoutubeVO get(int id) {
		for ( YoutubeVO youtubeVO :  youtubeList ) {
			if ( id == youtubeVO.getId() ) {
				return youtubeVO;
			}
		}
		return null;
	}
	
	public void remove(int id) {
		YoutubeVO youtubeVO = get(id);
		youtubeList.remove(youtubeVO);
	}
	
	public void update(int id, YoutubeVO youtubeVO) {
		int index = youtubeList.indexOf(get(id));
		youtubeList.set(index, youtubeVO);
		
	}
	
}
