package net.youtube.video.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.youtube.video.dao.YoutubeDao;
import net.youtube.video.vo.YoutubeVO;

@WebServlet("/regist")
public class RegistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private YoutubeDao youtubeDao;
	
    public RegistServlet() {
    	youtubeDao = YoutubeDao.getInstance();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/video/regist.jsp");
		rd.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String title = request.getParameter("title");
		String uploader = request.getParameter("uploader");
		String body = request.getParameter("body");
		String date = request.getParameter("date");
		String image = request.getParameter("image");
		
		YoutubeVO video = new YoutubeVO();
		video.setBody(body);
		video.setDate(date);
		video.setImage(image);
		video.setTitle(title);
		video.setUploader(uploader);
		
		youtubeDao.save(video);
		
		response.sendRedirect("/Youtube/list");
		
	}
	

}
