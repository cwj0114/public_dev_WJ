package net.goodgag.article.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.goodgag.article.dao.ArticleDao;

@WebServlet("/remove")
public class RemoveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private ArticleDao articleDao;
	
    public RemoveServlet() {
    	articleDao = ArticleDao.getInstance();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		if (idStr == null) {
			idStr ="";
		}
		int id = 0;
		try {
			id = Integer.parseInt(idStr);
		}catch(NumberFormatException nfe) {
			id = 0;
		}
		
		boolean isSuccess = articleDao.remove(id);
		
		if(isSuccess ) {
			response.sendRedirect("/Goodgag/list");
		}else {
		 response.sendError(500," 존재하지 않은 게시글입니다. ");
			
		}
		
	}

}
