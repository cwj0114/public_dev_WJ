package net.goodgag.article.dao;

import java.util.ArrayList;
import java.util.List;

import net.goodgag.article.vo.ArticleVO;

public class ArticleDao {

	private static ArticleDao articleDao;
	
	private List<ArticleVO> articleList;
	private int id;
	
	private List<ArticleVO> articleBody;
	
	private ArticleDao() {
		
		articleList = new ArrayList<ArticleVO>();
		
		ArticleVO article = new ArticleVO();
		article.setId(++id);
		article.setTitle("주호민과 작업실을 합친 이말년 근황.jpg");
		article.setCommentCount(15);
		article.setWriter("개드립");
		article.setWriteDateTime("08:00");
		article.setBody("그림");
		articleList.add(article);
		
		article = new ArticleVO();
		article.setId(++id);
		article.setTitle("너...괜찮냐?.gif");
		article.setCommentCount(20);
		article.setWriter("개드립");
		article.setWriteDateTime("07:57");
		article.setBody("그림");
		articleList.add(article);
		
		article = new ArticleVO();
		article.setId(++id);
		article.setTitle("알고나면 적잖이 충격받는사실.jpg");
		article.setCommentCount(20);
		article.setWriter("개드립");
		article.setWriteDateTime("07:54");
		article.setBody("그림");
		articleList.add(article);
	}
	
	public static ArticleDao getInstance() {
		if ( articleDao == null ) {
			articleDao = new ArticleDao();
		}
		return articleDao;
	}
	
	public void save(ArticleVO articleVO) {
		articleVO.setId(++id);
		articleList.add(articleVO);
	}
	
	public ArticleVO get(int id) {
		for ( ArticleVO article : articleList ) {
			if ( id == article.getId() ) {
				return article;
			}
		}
		return null;
	}
	
	public List<ArticleVO> getAll() {
		return articleList;
	}
	
	public boolean remove(int id) {
		for(ArticleVO article : articleList) {
			if(id == article.getId()) { //객체로 지움
				articleList.remove(article);
				return true;
			}
		}
		return false;
	}
	/*
	public void remove(int id) {
		for(ArticleVO article : articleList) {
			if(id == article.getId()) { //객체로 지움
				articleList.remove(article);
				break;
			}
		}
	}*/
}
/*
package net.goodgag.article.dao;

import java.util.ArrayList;
import java.util.List;

import net.goodgag.article.vo.ArticleVO;

//data access : 글에 대한 정보를 얘가 가지고 있음
public class ArticleDao {

	private static ArticleDao articleDao;
	// 기사 리스트들을 가지고 있음
	private List<ArticleVO> articleList;
	private int id;

	private ArticleDao() {

		articleList = new ArrayList<ArticleVO>();
		// 초기화된 vo 에 값을 넣어줌

		// 메모리를 가지고 있어서 유지가 가능하다
		// 값이 재할당 되는 것이 아니라

		// servlet에 있는 메모리랑은 다름
		ArticleVO article = new ArticleVO();
		article.setId(++id);
		// id를 1 증가시키고 할당해라!!
		article.setTitle("너...괜찮냐?.gif");
		article.setCommentCount(20);
		article.setWriter("개드립");
		article.setWriteDateTime("2018.02.20 07:57");
		article.setBody("영상");
		articleList.add(article);

		article = new ArticleVO();
		article.setId(++id);
		article.setTitle("아침에 일어날 때 우리의 모습 .gif");
		article.setCommentCount(20);
		article.setWriter("개드립");
		article.setWriteDateTime("2018.02.20 07:31");
		article.setBody("영상");
		articleList.add(article);

		article = new ArticleVO();
		article.setId(++id);
		article.setTitle("헬스장의 엄격한 규칙.jpg");
		article.setCommentCount(20);
		article.setWriter("개드립");
		article.setWriteDateTime("2018.02.20 07:48");
		article.setBody("사진");
		articleList.add(article);

	}

	public static ArticleDao getInstance() {
		if (articleDao == null) {
			articleDao = new ArticleDao();
		}
		return articleDao;
	}

	//새로운 아이디에 id부여하고 전달받은 기사를 리스트 안에 넣어줌!!
	public void save(ArticleVO articleVO) {
		articleVO.setId(++id);
		articleList.add(articleVO);
	}

	//id가 부여된 번호로 보여주기
	public ArticleVO get(int id) {
		for (ArticleVO article : articleList) {
			if (id == article.getId()) {
				return article;
			}
		}
		return null;
	}
	//기사리스트 전체를 돌려줌
	public List<ArticleVO> getAll() {
		return articleList;
	}

}
*/