package net.goodgag.article.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.goodgag.article.vo.ArticleVO;

@WebServlet("/list")
public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("URL로 접근함!");
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<ArticleVO> articleList = new ArrayList<ArticleVO>();
		
		ArticleVO article = new ArticleVO();		
		article.setId(1);
		article.setTitle("주호민과 작업실을 합친 이말년 근황.jpg");
		article.setCommentCount(15);
		article.setWriter("개드립");
		article.setWriteDateTime("08:00");
		article.setBody("그림");
		articleList.add(article);
		
		article = new ArticleVO();		
		article.setId(2);
		article.setTitle("주호민과 작업실을 합친 이말년 근황.jpg");
		article.setCommentCount(15);
		article.setWriter("개드립");
		article.setWriteDateTime("08:00");
		article.setBody("그림");
		articleList.add(article);

		article = new ArticleVO();		
		article.setId(3);
		article.setTitle("주호민과 작업실을 합친 이말년 근황.jpg");
		article.setCommentCount(15);
		article.setWriter("개드립");
		article.setWriteDateTime("08:00");
		article.setBody("그림");
		articleList.add(article);
		
		request.setAttribute("articleList", articleList);
		
		RequestDispatcher rd = 
				request.getRequestDispatcher("/WEB-INF/view/article/list.jsp");
		rd.forward(request, response);
	}

}
