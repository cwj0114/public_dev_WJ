package net.goodgag.article.vo;

public class ArticleVO {

	private String title;
	private int commentCount;
	private String writer;
	private int id;
	private String writeDateTime;
	private String body;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getCommentCount() {
		return commentCount;
	}

	public void setCommentCount(int commentCount) {
		this.commentCount = commentCount;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getWriteDateTime() {
		return writeDateTime;
	}

	public void setWriteDateTime(String writeDateTime) {
		this.writeDateTime = writeDateTime;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}


}
