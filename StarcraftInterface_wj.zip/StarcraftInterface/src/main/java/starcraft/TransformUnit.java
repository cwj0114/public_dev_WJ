package starcraft;

public interface TransformUnit extends MechanicUnit {
	
	public void modeChange();
	
}
