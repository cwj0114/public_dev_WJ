package starcraft;

public interface GroundToAirUnit extends MechanicUnit {
	
	public void attackToAir();

}
