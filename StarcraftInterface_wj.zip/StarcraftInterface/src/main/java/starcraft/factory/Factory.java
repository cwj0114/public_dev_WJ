package starcraft.factory;

import starcraft.MechanicUnit;
import starcraft.PlantUnit;
import starcraft.TransformUnit;

public class Factory {

	public MechanicUnit createUnit(int unitType) {
		
		if ( unitType == 1) {
			return new Vulture();
		}
		else if ( unitType == 2) {
			return new SiegeTank();			
		}
		else if ( unitType == 3) {
			return new Goliath();
		}		
		else {
			return null;
		}
	}
	
	public static void main(String[] args) {
		Factory factory = new Factory();
		MechanicUnit vulture = factory.createUnit(1);
		MechanicUnit siegetank = factory.createUnit(2);
		MechanicUnit goliath = factory.createUnit(3);
		
		if ( vulture instanceof PlantUnit ) {
			((PlantUnit) vulture).spidermine();
		}
		if ( siegetank instanceof TransformUnit ) {
			((TransformUnit) siegetank).attack();
			((TransformUnit) siegetank).modeChange();
			((TransformUnit) siegetank).attack();
			((TransformUnit) siegetank).modeChange();
			((TransformUnit) siegetank).attack();
		}
	}
}
