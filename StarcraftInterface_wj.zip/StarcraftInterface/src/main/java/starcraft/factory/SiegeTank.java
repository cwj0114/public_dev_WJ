package starcraft.factory;

import java.util.Random;

import starcraft.TransformUnit;

public class SiegeTank implements TransformUnit {
	
	// 처음에 퉁퉁포로 가정
	int mode = 0;
	
	@Override
	public void move() {
		Random random = new Random();
		int randomNumber = random.nextInt(2);
		if ( randomNumber == 1 ) {
			System.out.println("Move it!");
		}
		else {
			System.out.println("Pro-ceedin'!");
		}		
	}

	@Override
	public void stop() {
		System.out.println("...");
	}

	@Override
	public void patroll() {
		for ( int i = 0; i < 10; i++ ) {
			move();
		}
	}

	@Override
	public void attack() {
		
		if ( mode == 0 ) {
			System.out.println("퉁!");
		}
		else {
			System.out.println("퍼엉!");
		}
	}

	@Override
	public void hold() {
		System.out.println("Yes, sir!");
	}

	@Override
	public void modeChange() {
				
		if ( mode == 0 ) {
			System.out.println("시즈모드 완료!");
			mode+=1;
		}
		else {
			System.out.println("퉁퉁포 완료!");
			mode=0;
		}
		
	}

}
