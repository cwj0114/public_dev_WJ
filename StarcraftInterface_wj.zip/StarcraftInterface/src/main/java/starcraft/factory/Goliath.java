package starcraft.factory;

import java.util.Random;

import starcraft.GroundToAirUnit;

public class Goliath implements GroundToAirUnit {

	@Override
	public void move() {
		Random random = new Random();
		int randomNumber = random.nextInt(2);
		if ( randomNumber == 1 ) {
			System.out.println("Acknowledged H.Q.!");
		}
		else {
			System.out.println("Confirmed.");
		}				
	}

	@Override
	public void stop() {
		System.out.println("...");
	}

	@Override
	public void patroll() {
		for ( int i = 0; i < 10; i++ ) {
			move();
		}		
	}

	@Override
	public void attack() {
		System.out.println("타다당!");
	}

	@Override
	public void hold() {
		System.out.println("Yes, sir!");
	}

	@Override
	public void attackToAir() {
		System.out.println("슈이잉~~");
	}

}
