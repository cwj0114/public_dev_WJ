package starcraft;

public interface MechanicUnit {
	
	// 이동, 정지, 순찰, 공격, 사수
		public void move();
		public void stop();
		public void patroll();
		public void attack();
		public void hold();
		
}
