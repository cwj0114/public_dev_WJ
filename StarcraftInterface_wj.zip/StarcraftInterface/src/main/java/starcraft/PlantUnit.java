package starcraft;

public interface PlantUnit extends MechanicUnit {
	
	public void spidermine();	
	
}
